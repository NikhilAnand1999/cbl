<table class="table table-light">
    <thead class="thead-light">
        <tr>
            <th>#</th>
            <th>User</th>
            <th>Title</th>
            <th>Desc</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($post->id); ?></td>
            <td><?php echo e($post->user->name); ?></td>
            <td><?php echo e($post->name); ?></td>
            <td><?php echo e($post->description); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th>#</th>
            <th>#</th>
            <th>#</th>
            <th>#</th>
        </tr>
    </tfoot>
</table>

<div>

    <?php echo e($posts->links()); ?>

</div>
<?php /**PATH /home/shubham/example-app/resources/views/posts/index.blade.php ENDPATH**/ ?>